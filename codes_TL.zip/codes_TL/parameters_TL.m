function [omega,alpha,Topt,eps_sun,eps_shade] = parameters_TL(LandCoverTypeNumber) % only ESA-CCI landcover
                if (LandCoverTypeNumber==70||LandCoverTypeNumber==71||LandCoverTypeNumber==72)    
                    omega = 0.6;
                    alpha = 0.15;
                    Topt = 19.7;
                    eps_sun= 0.89;
                    eps_shade= 3.40; 

                elseif LandCoverTypeNumber==50 
                    omega = 0.8;
                    alpha = 0.18;
                    Topt = 25.8;
                    eps_sun = 1.44;
                    eps_shade = 3.26; 

                elseif (LandCoverTypeNumber==80||LandCoverTypeNumber==81||LandCoverTypeNumber==82) 
                    omega = 0.6;
                    alpha = 0.15;
                    eps_sun = 0.92;
                    eps_shade = 3.75;
                    Topt = 23.1;

                elseif ( LandCoverTypeNumber==60||LandCoverTypeNumber==61||LandCoverTypeNumber==62)   
                    omega = 0.8;
                    alpha = 0.18;
                    eps_sun = 0.92;
                    eps_shade = 3.75;
                    Topt = 23.1;

                elseif LandCoverTypeNumber==90  
                    omega = 0.7;
                    alpha = 0.17;
                    Topt = 24.5;
                    eps_sun = 0.8;
                    eps_shade = 3.0;

                elseif (LandCoverTypeNumber==120||LandCoverTypeNumber==121||LandCoverTypeNumber==122) 
                    omega = 0.8;
                    alpha = 0.16;
                    Topt = 22.3;
                    eps_sun = 0.65;
                    eps_shade = 3.10;

                elseif LandCoverTypeNumber==100 
                    omega = 0.8;
                    alpha = 0.23;
                    Topt = 26.2;
                    eps_sun = 2.60;
                    eps_shade = 2.70;

                elseif LandCoverTypeNumber==110  
                    omega = 0.8;
                    alpha = 0.16;
                    Topt = 25.8;
                    eps_sun = 3.45;
                    eps_shade = 4.65;
        
                elseif LandCoverTypeNumber==130 
                    omega = 0.9;
                    alpha = 0.23;
                    Topt = 20.9;
                    eps_sun = 1.16;
                    eps_shade = 4.57;

                elseif (LandCoverTypeNumber==12||LandCoverTypeNumber==10||LandCoverTypeNumber==11||LandCoverTypeNumber==20||LandCoverTypeNumber==30||LandCoverTypeNumber==40)  
                    omega = 0.9;
                    alpha = 0.23;
                    Topt = 23.5;
                    eps_sun = 1.43;  
                    eps_shade = 4.8; 

                elseif (LandCoverTypeNumber==160||LandCoverTypeNumber==170||LandCoverTypeNumber==180)  
                    omega = 0.9;
                    alpha = 0.23;
                    Topt = 24.2;
                    eps_sun = 1.23;
                    eps_shade = 2.53;
                   
                else
                    omega = 0;
                    alpha = 0;
                     eps_sun = 0;
                    eps_shade = 0;
                 
                 end