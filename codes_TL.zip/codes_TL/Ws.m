function g=Ws(vpd)
                VPDmax=4.1;  
                VPDmin=0.93;
                if (vpd < VPDmin)
                    g = 1;
                elseif (vpd> VPDmax)
                    g = 0;
                else
                    g = (VPDmax - vpd) / (VPDmax - VPDmin);
                end