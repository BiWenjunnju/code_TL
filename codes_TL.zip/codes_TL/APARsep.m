function [APARsun,APARshade]=APARsep(costha_m,LAIsun,LAIshade,lai,PARdif_under,C,PARdif,PARdir)

 PARshade = (1 - alpha)*((PARdif - PARdif_under) / lai + C);
 PARsun = (1 - alpha)*PARdir*0.5 / costha_m + PARshade;
 APARsun = LAIsun*PARsun;
 APARshade = LAIshade*PARshade;