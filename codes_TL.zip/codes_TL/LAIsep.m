function [LAIsun,LAIshade]=LAIsep(omega,lai,costha_m)
LAIsun = 2 * costha_m * (1 - exp(-0.5 * omega * lai / costha_m));
                LAIshade = laix - LAIsun;